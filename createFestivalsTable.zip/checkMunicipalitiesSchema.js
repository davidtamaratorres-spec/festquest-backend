const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function run() {
  try {
    const columns = await pool.query(`
      SELECT column_name, data_type
      FROM information_schema.columns
      WHERE table_name = 'municipalities'
      ORDER BY ordinal_position;
    `);

    const count = await pool.query(`
      SELECT COUNT(*)::int AS total FROM municipalities;
    `);

    console.log("=== COLUMNAS DE municipalities ===");
    columns.rows.forEach((row) => {
      console.log(`${row.column_name} -> ${row.data_type}`);
    });

    console.log("\n=== TOTAL MUNICIPIOS ===");
    console.log(count.rows[0].total);
  } catch (error) {
    console.error("❌ Error:", error.message);
  } finally {
    await pool.end();
  }
}

run();