const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function check() {
  const res = await pool.query("SELECT id, nombre FROM municipalities LIMIT 10");
  console.log(res.rows);
  await pool.end();
}

check();