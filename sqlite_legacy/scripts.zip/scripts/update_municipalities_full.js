const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const db = require("../db");

const filePath = path.join(__dirname, "../data/datos_nacionales_subregion.csv");

function limpiarCodigo(valor) {
  if (!valor) return null;

  return String(valor)
    .replace(/"/g, "")
    .replace(/,/g, "")
    .trim()
    .replace(/^0+/, "");
}

async function run() {
  try {
    let procesados = 0;
    let encontrados = 0;
    let noEncontrados = 0;

    const stream = fs.createReadStream(filePath).pipe(csv());

    for await (const row of stream) {
      procesados++;

      const codigo = limpiarCodigo(row["Codigo_id"]);

      if (!codigo || codigo === "0") {
        continue;
      }

      const existe = await db.query(
        `SELECT id FROM municipalities WHERE codigo_dane::text = $1`,
        [codigo]
      );

      if (existe.rowCount === 0) {
        noEncontrados++;
        continue;
      }

      await db.query(
        `
        UPDATE municipalities
        SET
          subregion = COALESCE(NULLIF($1, ''), subregion),
          habitantes = COALESCE(NULLIF($2, '')::int, habitantes),
          temperatura_promedio = COALESCE(NULLIF($3, '')::numeric, temperatura_promedio),
          altura = COALESCE(NULLIF($4, '')::int, altura)
        WHERE codigo_dane::text = $5
        `,
        [
          row["Subregion"] || null,
          row["habitantes"] || null,
          row["temperatura_promedio"] || null,
          row["altura"] || null,
          codigo,
        ]
      );

      encontrados++;

      if (encontrados % 100 === 0) {
        console.log(`Actualizados: ${encontrados}`);
      }
    }

    console.log("✅ Proceso terminado");
    console.log("Filas leídas:", procesados);
    console.log("Coincidencias encontradas:", encontrados);
    console.log("No encontradas:", noEncontrados);
    process.exit(0);
  } catch (err) {
    console.error("❌ Error:", err.message);
    process.exit(1);
  }
}

run();