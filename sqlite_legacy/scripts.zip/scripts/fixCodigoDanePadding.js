const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function run() {
  try {
    console.log("Corrigiendo formato de codigo_dane...");

    await pool.query(`
      UPDATE municipalities
      SET codigo_dane = LPAD(codigo_dane::text, 5, '0')
    `);

    console.log("✅ codigo_dane corregido a 5 dígitos");
  } catch (err) {
    console.error("❌ Error:", err.message);
  } finally {
    await pool.end();
  }
}

run();