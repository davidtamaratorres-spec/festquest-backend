const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

const baseFile = path.join(__dirname, "..", "data", "datos_nacionales_base.csv");
const climaFile = path.join(__dirname, "..", "data", "datos_nacionales_clima.csv");
const geoFile = path.join(__dirname, "..", "data", "datos_nacionales_geo.csv");
const subregionFile = path.join(__dirname, "..", "data", "datos_nacionales_subregion.csv");

function loadCSV(file) {
  return new Promise((resolve, reject) => {
    const rows = [];
    fs.createReadStream(file)
      .pipe(csv())
      .on("data", (row) => rows.push(row))
      .on("end", () => resolve(rows))
      .on("error", reject);
  });
}

function clean(v) {
  return String(v ?? "").trim();
}

function normalize(code) {
  const c = clean(code);
  if (!c || c === "0") return null;
  return c.padStart(5, "0");
}

function toInt(v) {
  const n = parseInt(clean(v).replace(/[^\d-]/g, ""), 10);
  return Number.isNaN(n) ? null : n;
}

function toNum(v) {
  const n = parseFloat(clean(v).replace(",", "."));
  return Number.isNaN(n) ? null : n;
}

async function run() {
  const [base, clima, geo, subregion] = await Promise.all([
    loadCSV(baseFile),
    loadCSV(climaFile),
    loadCSV(geoFile),
    loadCSV(subregionFile),
  ]);

  const climaMap = Object.fromEntries(clima.map(r => [normalize(r.Codigo_id), r]));
  const geoMap = Object.fromEntries(geo.map(r => [normalize(r.Codigo_id), r]));
  const subMap = Object.fromEntries(subregion.map(r => [normalize(r.Codigo_id), r]));

  let updated = 0;

  for (const r of base) {
    const code = normalize(r.Codigo_id);
    if (!code) continue;

    const g = geoMap[code];
    const c = climaMap[code];
    const s = subMap[code];

    const habitantes = g ? toInt(g.habitantes) : null;
    const altura = g ? toInt(g.altura) : null;
    const temperatura = c ? toNum(c.temperatura_promedio) : null;
    const subregion = s ? clean(s.Subregion) : null;

    await pool.query(
      `
      UPDATE municipalities
      SET
        habitantes = COALESCE($1, habitantes),
        altura = COALESCE($2, altura),
        temperatura_promedio = COALESCE($3, temperatura_promedio),
        subregion = COALESCE(NULLIF($4, ''), subregion)
      WHERE codigo_dane = $5
      `,
      [habitantes, altura, temperatura, subregion, code]
    );

    updated++;
  }

  console.log("Procesados:", updated);

  await pool.end();
}

run();