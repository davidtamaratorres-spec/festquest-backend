const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

const filePath = path.join(__dirname, "..", "data", "festivals_master.csv");

async function ensureUniqueConstraint() {
  try {
    await pool.query(`
      ALTER TABLE festivals
      ADD CONSTRAINT unique_festival_municipio_nombre_year
      UNIQUE (municipio_id, nombre, year)
    `);
    console.log("✅ Constraint único creado en festivals");
  } catch (error) {
    if (error.message.includes("already exists")) {
      console.log("ℹ️ Constraint único ya existía");
    } else {
      console.log("ℹ️ No se pudo crear constraint único:", error.message);
    }
  }
}

async function run() {
  try {
    console.log("🚀 Importando festivales...");

    if (!fs.existsSync(filePath)) {
      throw new Error("No existe festivals_master.csv");
    }

    await ensureUniqueConstraint();

    const rows = [];

    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (row) => rows.push(row))
      .on("end", async () => {
        let inserted = 0;
        let skipped = 0;
        let notFound = 0;

        for (const r of rows) {
          const codigo = String(r.municipio_codigo_dane || "").trim();
          const nombre = String(r.nombre || "").trim();

          if (!codigo || !nombre) {
            skipped++;
            console.log(`⚠️ Saltado por datos incompletos: ${nombre || "(sin nombre)"}`);
            continue;
          }

          const mun = await pool.query(
            `SELECT id FROM municipalities WHERE codigo_dane = $1 LIMIT 1`,
            [codigo]
          );

          if (mun.rows.length === 0) {
            notFound++;
            console.log(`❌ Municipio no encontrado: ${codigo}`);
            continue;
          }

          const municipio_id = mun.rows[0].id;
          const year = r.year ? parseInt(r.year, 10) : null;
          const date_start = r.date_start || null;
          const date_end = r.date_end || null;
          const descripcion = r.descripcion || null;
          const status = r.status || "confirmado";
          const source_name = r.source_name || null;
          const source_url = r.source_url || null;

          try {
            const result = await pool.query(
              `
              INSERT INTO festivals
              (
                municipio_id,
                nombre,
                descripcion,
                year,
                date_start,
                date_end,
                status,
                source_name,
                source_url
              )
              VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
              ON CONFLICT (municipio_id, nombre, year) DO NOTHING
              RETURNING id
              `,
              [
                municipio_id,
                nombre,
                descripcion,
                year,
                date_start,
                date_end,
                status,
                source_name,
                source_url,
              ]
            );

            if (result.rows.length > 0) {
              inserted++;
              console.log(`✔ Insertado: ${nombre}`);
            } else {
              skipped++;
              console.log(`⚠️ Ya existía: ${nombre}`);
            }
          } catch (e) {
            skipped++;
            console.log(`⚠️ Saltado: ${nombre} -> ${e.message}`);
          }
        }

        console.log("\n=== RESULTADO ===");
        console.log("Insertados:", inserted);
        console.log("Saltados:", skipped);
        console.log("Municipios no encontrados:", notFound);

        await pool.end();
      })
      .on("error", async (error) => {
        console.error("❌ Error leyendo CSV:", error.message);
        await pool.end();
      });
  } catch (err) {
    console.error("❌ Error:", err.message);
    await pool.end();
  }
}

run();