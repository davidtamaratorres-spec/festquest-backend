const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

const filePath = path.join(__dirname, "..", "data", "municipios_de_colombia.csv");

function clean(v) {
  return String(v ?? "").trim();
}

function toInt(v) {
  const n = parseInt(clean(v).replace(/[^\d-]/g, ""), 10);
  return Number.isNaN(n) ? null : n;
}

function toNum(v) {
  const n = parseFloat(clean(v).replace(",", "."));
  return Number.isNaN(n) ? null : n;
}

async function run() {
  const rows = [];

  console.log("Leyendo municipios...");

  fs.createReadStream(filePath)
    .pipe(csv())
    .on("data", (row) => rows.push(row))
    .on("end", async () => {

      let updated = 0;
      let fallback = 0;
      let failed = 0;

      for (const r of rows) {

        const codigo = clean(r.Codigo_id);
        const nombre = clean(r.municipio);
        const departamento = clean(r.departamento);

        let result = await pool.query(
          `
          UPDATE municipalities
          SET
            subregion = $1,
            habitantes = $2,
            temperatura_promedio = $3,
            altura = $4
          WHERE codigo_dane = $5
          `,
          [
            clean(r.Subregion),
            toInt(r.habitantes),
            toNum(r.temperatura_promedio),
            toInt(r.altura),
            codigo
          ]
        );

        // 👉 fallback por nombre
        if (result.rowCount === 0) {
          result = await pool.query(
            `
            UPDATE municipalities
            SET
              subregion = $1,
              habitantes = $2,
              temperatura_promedio = $3,
              altura = $4
            WHERE LOWER(nombre) = LOWER($5)
            AND LOWER(departamento) = LOWER($6)
            `,
            [
              clean(r.Subregion),
              toInt(r.habitantes),
              toNum(r.temperatura_promedio),
              toInt(r.altura),
              nombre,
              departamento
            ]
          );

          if (result.rowCount > 0) {
            fallback++;
          } else {
            failed++;
          }
        }

        if (result.rowCount > 0) updated++;
      }

      console.log("Actualizados:", updated);
      console.log("Por fallback:", fallback);
      console.log("No encontrados:", failed);

      await pool.end();
    });
}

run();