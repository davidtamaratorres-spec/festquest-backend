const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function run() {
  try {
    console.log("Corrigiendo tipos de datos...");

    await pool.query(`
      ALTER TABLE municipalities
      ALTER COLUMN habitantes TYPE INTEGER USING habitantes::INTEGER;
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ALTER COLUMN altura TYPE INTEGER USING altura::INTEGER;
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ALTER COLUMN temperatura_promedio TYPE DECIMAL(5,2)
      USING temperatura_promedio::DECIMAL;
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ALTER COLUMN codigo_dane TYPE VARCHAR(10);
    `);

    console.log("✅ Tipos corregidos correctamente");
  } catch (err) {
    console.error("❌ Error:", err.message);
  } finally {
    await pool.end();
  }
}

run();