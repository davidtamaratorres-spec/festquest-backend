const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const db = require("../db");

const filePath = path.join(__dirname, "../data/datos_nacionales_subregion.csv");

function get(row, key) {
  const k = Object.keys(row).find(
    (h) => h.trim().toLowerCase() === key.toLowerCase()
  );
  return k ? row[k] : null;
}

function limpiarTexto(v) {
  if (v === undefined || v === null) return null;
  const s = String(v).replace(/"/g, "").trim();
  return s === "" ? null : s;
}

function limpiarEntero(v) {
  const s = limpiarTexto(v);
  if (!s) return null;

  const n = Number(s);
  if (Number.isNaN(n)) return null;

  return Math.round(n);
}

function limpiarDecimal(v) {
  const s = limpiarTexto(v);
  if (!s) return null;

  const n = Number(s);
  if (Number.isNaN(n)) return null;

  return n;
}

async function run() {
  try {
    await db.query("TRUNCATE TABLE festivals CASCADE;");
    await db.query("TRUNCATE TABLE municipalities CASCADE;");
    console.log("🧹 Tablas vaciadas");

    let count = 0;

    const stream = fs.createReadStream(filePath).pipe(csv());

    for await (const row of stream) {
      const codigo = limpiarTexto(get(row, "Codigo_id"));

      if (!codigo || codigo === "0" || codigo === "00000") continue;

      await db.query(
        `
        INSERT INTO municipalities
        (codigo_dane, nombre, departamento, subregion, habitantes, temperatura_promedio, altura)
        VALUES ($1,$2,$3,$4,$5,$6,$7)
        `,
        [
          codigo,
          limpiarTexto(get(row, "municipio")),
          limpiarTexto(get(row, "departamento")),
          limpiarTexto(get(row, "Subregion")),
          limpiarEntero(get(row, "habitantes")),
          limpiarDecimal(get(row, "temperatura_promedio")),
          limpiarEntero(get(row, "altura")),
        ]
      );

      count++;

      if (count % 100 === 0) {
        console.log(`Insertados: ${count}`);
      }
    }

    console.log("✅ Carga completa:", count);
    process.exit(0);
  } catch (err) {
    console.error("❌ Error:", err.message);
    process.exit(1);
  }
}

run();