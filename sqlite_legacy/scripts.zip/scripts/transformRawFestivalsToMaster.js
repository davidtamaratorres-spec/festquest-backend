const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");

const rawFilePath = path.join(__dirname, "..", "data", "festivals_raw_big.csv");
const masterFilePath = path.join(__dirname, "..", "data", "festivals_master.csv");

function detectYear(fechaText) {
  const text = String(fechaText || "").trim();
  const match = text.match(/\b(20\d{2})\b/);
  if (match) return parseInt(match[1], 10);
  return 2026;
}

async function run() {
  try {
    console.log("Transformando festivals_raw_big.csv a festivals_master.csv...");

    if (!fs.existsSync(rawFilePath)) {
      throw new Error("No existe data/festivals_raw_big.csv");
    }

    const rows = [];

    fs.createReadStream(rawFilePath)
      .pipe(csv())
      .on("data", (row) => rows.push(row))
      .on("end", () => {
        const output = [];
        output.push(
          "municipio_codigo_dane,nombre,year,date_start,date_end,descripcion,status,source_name,source_url"
        );

        let added = 0;
        let skipped = 0;

        for (const r of rows) {
          const codigo = String(r.codigo_dane || "").trim().padStart(5, "0");
          const nombre = String(r.nombre || "").trim();
          const fechaText = String(r.fecha_text || "").trim();
          const sourceName = String(r.source_name || "").trim();
          const sourceUrl = String(r.source_url || "").trim();

          if (!codigo || !nombre) {
            skipped++;
            continue;
          }

          const year = detectYear(fechaText);
          const descripcion = fechaText
            ? `Fecha referencial: ${fechaText.replace(/"/g, "'")}`
            : "Festival por verificar";
          const status = "por_verificar";

          output.push(
            [
              codigo,
              `"${nombre.replace(/"/g, '""')}"`,
              year,
              "",
              "",
              `"${descripcion}"`,
              status,
              `"${sourceName.replace(/"/g, '""')}"`,
              `"${sourceUrl.replace(/"/g, '""')}"`
            ].join(",")
          );

          added++;
        }

        fs.writeFileSync(masterFilePath, output.join("\n"), "utf8");

        console.log("✅ Transformación completada");
        console.log("Filas convertidas:", added);
        console.log("Filas omitidas:", skipped);
        console.log("Archivo generado:", masterFilePath);
      })
      .on("error", (error) => {
        console.error("❌ Error leyendo CSV crudo:", error.message);
      });
  } catch (error) {
    console.error("❌ Error:", error.message);
  }
}

run();