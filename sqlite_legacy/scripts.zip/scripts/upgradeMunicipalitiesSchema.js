const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function run() {
  try {
    console.log("Actualizando esquema de municipalities...");

    await pool.query(`
      ALTER TABLE municipalities
      ADD COLUMN IF NOT EXISTS codigo_dane VARCHAR(10);
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ADD COLUMN IF NOT EXISTS subregion VARCHAR(255);
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ADD COLUMN IF NOT EXISTS habitantes INTEGER;
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ADD COLUMN IF NOT EXISTS temperatura_promedio DECIMAL(5,2);
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ADD COLUMN IF NOT EXISTS altura INTEGER;
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ADD COLUMN IF NOT EXISTS nombre_normalizado VARCHAR(255);
    `);

    await pool.query(`
      ALTER TABLE municipalities
      ADD COLUMN IF NOT EXISTS slug VARCHAR(255);
    `);

    console.log("✅ Esquema de municipalities actualizado correctamente");
  } catch (err) {
    console.error("❌ Error:", err.message);
  } finally {
    await pool.end();
  }
}

run();