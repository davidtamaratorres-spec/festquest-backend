const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function run() {
  try {
    console.log("Priorizando festivales REAL sobre BASE...");

    const result = await pool.query(`
      UPDATE festivals base
      SET is_active = false
      FROM festivals real
      WHERE 
        base.municipio_id = real.municipio_id
        AND LOWER(base.nombre) = LOWER(real.nombre)
        AND base.source_type = 'base'
        AND real.source_type = 'real';
    `);

    console.log("Bases desactivados:", result.rowCount);

    const check = await pool.query(`
      SELECT source_type, is_active, COUNT(*) as total
      FROM festivals
      GROUP BY source_type, is_active
      ORDER BY source_type, is_active;
    `);

    console.log("Estado final:");
    console.table(check.rows);

    await pool.end();
  } catch (err) {
    console.error("Error:", err.message);
    await pool.end();
    process.exit(1);
  }
}

run();