const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false,
});

const CSV_PATH = path.join(__dirname, "..", "data", "datos_nacionales.csv");

function parseCsvLine(line) {
  const result = [];
  let current = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const next = line[i + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      result.push(current);
      current = "";
    } else {
      current += char;
    }
  }

  result.push(current);
  return result.map((v) => v.trim());
}

function parseCsv(content) {
  const lines = content
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  if (lines.length < 2) return [];

  const headers = parseCsvLine(lines[0]);

  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    const row = {};

    headers.forEach((header, index) => {
      row[header] = values[index] ?? "";
    });

    return row;
  });
}

function toNull(value) {
  if (value === undefined || value === null) return null;
  const v = String(value).trim();
  return v === "" ? null : v;
}

function normalizeNumber(value) {
  const raw = toNull(value);
  if (!raw) return null;

  const cleaned = raw.replace(/\./g, "").replace(/,/g, ".");
  const num = Number(cleaned);

  return Number.isNaN(num) ? null : num;
}

function normalizeInteger(value) {
  const num = normalizeNumber(value);
  if (num === null) return null;
  return Math.round(num);
}

function normalizeDate(value) {
  const raw = toNull(value);
  if (!raw) return null;

  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return null;

  return raw;
}

async function ensureFestivalUniqueIndex() {
  const sql = `
    CREATE UNIQUE INDEX IF NOT EXISTS idx_festivals_unique_seed
    ON festivals (nombre, municipio_id, fecha);
  `;
  await pool.query(sql);
}

async function upsertMunicipality(client, row) {
  const codigoDane = normalizeInteger(row.Codigo_id);
  const nombre = toNull(row.municipio);
  const departamento = toNull(row.departamento);
  const subregion = toNull(row.Subregion);
  const habitantes = normalizeInteger(row.habitantes);
  const temperaturaPromedio = normalizeNumber(row.temperatura_promedio);
  const altura = normalizeNumber(row.altura);

  if (!codigoDane || !nombre || !departamento) {
    throw new Error(
      `Municipio inválido. codigo=${row.Codigo_id}, municipio=${row.municipio}, departamento=${row.departamento}`
    );
  }

  const updateByCode = await client.query(
    `
    UPDATE municipalities
    SET
      nombre = $2,
      departamento = $3,
      subregion = COALESCE($4, subregion),
      habitantes = COALESCE($5, habitantes),
      temperatura_promedio = COALESCE($6, temperatura_promedio),
      altura = COALESCE($7, altura),
      codigo_dane = $1
    WHERE codigo_dane = $1
    RETURNING id
    `,
    [
      codigoDane,
      nombre,
      departamento,
      subregion,
      habitantes,
      temperaturaPromedio,
      altura,
    ]
  );

  if (updateByCode.rows.length > 0) {
    return updateByCode.rows[0].id;
  }

  const updateByName = await client.query(
    `
    UPDATE municipalities
    SET
      codigo_dane = COALESCE(codigo_dane, $1),
      departamento = $3,
      subregion = COALESCE($4, subregion),
      habitantes = COALESCE($5, habitantes),
      temperatura_promedio = COALESCE($6, temperatura_promedio),
      altura = COALESCE($7, altura)
    WHERE LOWER(nombre) = LOWER($2)
    RETURNING id
    `,
    [
      codigoDane,
      nombre,
      departamento,
      subregion,
      habitantes,
      temperaturaPromedio,
      altura,
    ]
  );

  if (updateByName.rows.length > 0) {
    return updateByName.rows[0].id;
  }

  const insertResult = await client.query(
    `
    INSERT INTO municipalities
      (codigo_dane, nombre, departamento, subregion, habitantes, temperatura_promedio, altura)
    VALUES
      ($1, $2, $3, $4, $5, $6, $7)
    RETURNING id
    `,
    [
      codigoDane,
      nombre,
      departamento,
      subregion,
      habitantes,
      temperaturaPromedio,
      altura,
    ]
  );

  return insertResult.rows[0].id;
}

async function upsertFestival(client, municipalityId, row) {
  const nombre = toNull(row.festival);
  const fecha = normalizeDate(row.fecha);

  if (!nombre || !fecha) {
    return { inserted: false, updated: false, skipped: true };
  }

  const payload = {
    nombre,
    fecha,
    descripcion: null,
    municipio_id: municipalityId,
    sitio_1: toNull(row.sitio_1),
    maps_1: toNull(row.maps_1),
    sitio_2: toNull(row.sitio_2),
    maps_2: toNull(row.maps_2),
    sitio_3: toNull(row.sitio_3),
    maps_3: toNull(row.maps_3),
    hotel_1: toNull(row.hotel_1),
    wa_1: toNull(row.wa_1),
    hotel_2: toNull(row.hotel_2),
    wa_2: toNull(row.wa_2),
    hotel_3: toNull(row.hotel_3),
    wa_3: toNull(row.wa_3),
  };

  const updateResult = await client.query(
    `
    UPDATE festivals
    SET
      descripcion = COALESCE($4, descripcion),
      sitio_1 = COALESCE($5, sitio_1),
      maps_1 = COALESCE($6, maps_1),
      sitio_2 = COALESCE($7, sitio_2),
      maps_2 = COALESCE($8, maps_2),
      sitio_3 = COALESCE($9, sitio_3),
      maps_3 = COALESCE($10, maps_3),
      hotel_1 = COALESCE($11, hotel_1),
      wa_1 = COALESCE($12, wa_1),
      hotel_2 = COALESCE($13, hotel_2),
      wa_2 = COALESCE($14, wa_2),
      hotel_3 = COALESCE($15, hotel_3),
      wa_3 = COALESCE($16, wa_3)
    WHERE nombre = $1
      AND municipio_id = $2
      AND fecha = $3
    RETURNING id
    `,
    [
      payload.nombre,
      payload.municipio_id,
      payload.fecha,
      payload.descripcion,
      payload.sitio_1,
      payload.maps_1,
      payload.sitio_2,
      payload.maps_2,
      payload.sitio_3,
      payload.maps_3,
      payload.hotel_1,
      payload.wa_1,
      payload.hotel_2,
      payload.wa_2,
      payload.hotel_3,
      payload.wa_3,
    ]
  );

  if (updateResult.rows.length > 0) {
    return { inserted: false, updated: true, skipped: false };
  }

  await client.query(
    `
    INSERT INTO festivals
      (
        nombre,
        fecha,
        descripcion,
        municipio_id,
        sitio_1,
        maps_1,
        sitio_2,
        maps_2,
        sitio_3,
        maps_3,
        hotel_1,
        wa_1,
        hotel_2,
        wa_2,
        hotel_3,
        wa_3
      )
    VALUES
      (
        $1, $2, $3, $4,
        $5, $6, $7, $8,
        $9, $10, $11, $12,
        $13, $14, $15, $16
      )
    `,
    [
      payload.nombre,
      payload.fecha,
      payload.descripcion,
      payload.municipio_id,
      payload.sitio_1,
      payload.maps_1,
      payload.sitio_2,
      payload.maps_2,
      payload.sitio_3,
      payload.maps_3,
      payload.hotel_1,
      payload.wa_1,
      payload.hotel_2,
      payload.wa_2,
      payload.hotel_3,
      payload.wa_3,
    ]
  );

  return { inserted: true, updated: false, skipped: false };
}

async function main() {
  if (!fs.existsSync(CSV_PATH)) {
    throw new Error(`No existe el archivo: ${CSV_PATH}`);
  }

  const csvContent = fs.readFileSync(CSV_PATH, "utf8");
  const rows = parseCsv(csvContent);

  if (!rows.length) {
    throw new Error("El CSV está vacío o no se pudo leer.");
  }

  console.log(`📄 Filas leídas del CSV: ${rows.length}`);

  await ensureFestivalUniqueIndex();

  const client = await pool.connect();

  let municipiosProcesados = 0;
  let festivalesInsertados = 0;
  let festivalesActualizados = 0;
  let festivalesOmitidos = 0;

  try {
    await client.query("BEGIN");

    for (const row of rows) {
      const municipalityId = await upsertMunicipality(client, row);
      municipiosProcesados++;

      const fest = await upsertFestival(client, municipalityId, row);

      if (fest.inserted) festivalesInsertados++;
      if (fest.updated) festivalesActualizados++;
      if (fest.skipped) festivalesOmitidos++;
    }

    await client.query("COMMIT");

    console.log("✅ Seed piloto completado");
    console.log(`🏙 Municipios procesados: ${municipiosProcesados}`);
    console.log(`🎉 Festivales insertados: ${festivalesInsertados}`);
    console.log(`🔄 Festivales actualizados: ${festivalesActualizados}`);
    console.log(`⏭ Festivales omitidos: ${festivalesOmitidos}`);
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("❌ Error en seed piloto:", error.message);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((error) => {
  console.error("❌ Proceso terminado con error:", error.message);
  process.exit(1);
});