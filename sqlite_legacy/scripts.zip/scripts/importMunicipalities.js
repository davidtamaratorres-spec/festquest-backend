const fs = require("fs");
const path = require("path");
const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

function normalizeText(text) {
  return String(text || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function slugifyMunicipality(nombre, departamento) {
  const full = `${nombre}-${departamento}`;
  return normalizeText(full)
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

function parseCSVLine(line) {
  const result = [];
  let current = "";
  let insideQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (char === '"') {
      if (insideQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === "," && !insideQuotes) {
      result.push(current);
      current = "";
    } else {
      current += char;
    }
  }

  result.push(current);
  return result.map((value) => value.trim());
}

async function ensureMunicipalitiesTable() {
  const query = `
    CREATE TABLE IF NOT EXISTS municipalities (
      id SERIAL PRIMARY KEY,
      codigo_divipola VARCHAR(10) UNIQUE NOT NULL,
      nombre VARCHAR(255) NOT NULL,
      departamento VARCHAR(255) NOT NULL,
      nombre_normalizado VARCHAR(255),
      slug VARCHAR(255),
      poblacion INTEGER,
      altura INTEGER,
      lat DECIMAL(9,6),
      lng DECIMAL(9,6),
      activo BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT NOW()
    );
  `;

  await pool.query(query);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_municipalities_departamento
    ON municipalities(departamento);
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_municipalities_nombre_normalizado
    ON municipalities(nombre_normalizado);
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_municipalities_slug
    ON municipalities(slug);
  `);
}

async function importMunicipalities() {
  const filePath = path.join(__dirname, "..", "data", "municipalities.csv");

  if (!fs.existsSync(filePath)) {
    throw new Error(`No existe el archivo: ${filePath}`);
  }

  const raw = fs.readFileSync(filePath, "utf8");
  const lines = raw
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.length > 0);

  if (lines.length < 2) {
    throw new Error("El archivo CSV no tiene datos suficientes.");
  }

  const header = parseCSVLine(lines[0]).map((h) => normalizeText(h));

  const idxCodigo = header.indexOf("codigo_divipola");
  const idxMunicipio = header.indexOf("nombre");
  const idxDepartamento = header.indexOf("departamento");

  if (idxCodigo === -1 || idxMunicipio === -1 || idxDepartamento === -1) {
    throw new Error(
      "El CSV debe tener estas columnas exactas: codigo_divipola,nombre,departamento"
    );
  }

  let inserted = 0;
  let updated = 0;
  let skipped = 0;

  for (let i = 1; i < lines.length; i++) {
    const cols = parseCSVLine(lines[i]);

    const codigo_divipola = String(cols[idxCodigo] || "").trim();
    const nombre = String(cols[idxMunicipio] || "").trim();
    const departamento = String(cols[idxDepartamento] || "").trim();

    if (!codigo_divipola || !nombre || !departamento) {
      skipped++;
      console.log(`Fila ${i + 1} omitida por datos incompletos`);
      continue;
    }

    const nombre_normalizado = normalizeText(nombre);
    const slug = slugifyMunicipality(nombre, departamento);

    const existsQuery = `
      SELECT id
      FROM municipalities
      WHERE codigo_divipola = $1
      LIMIT 1
    `;
    const existsResult = await pool.query(existsQuery, [codigo_divipola]);

    if (existsResult.rows.length > 0) {
      const updateQuery = `
        UPDATE municipalities
        SET
          nombre = $1,
          departamento = $2,
          nombre_normalizado = $3,
          slug = $4,
          activo = TRUE
        WHERE codigo_divipola = $5
      `;
      await pool.query(updateQuery, [
        nombre,
        departamento,
        nombre_normalizado,
        slug,
        codigo_divipola,
      ]);
      updated++;
    } else {
      const insertQuery = `
        INSERT INTO municipalities (
          codigo_divipola,
          nombre,
          departamento,
          nombre_normalizado,
          slug,
          activo
        )
        VALUES ($1, $2, $3, $4, $5, TRUE)
      `;
      await pool.query(insertQuery, [
        codigo_divipola,
        nombre,
        departamento,
        nombre_normalizado,
        slug,
      ]);
      inserted++;
    }
  }

  console.log("===================================");
  console.log("Importación finalizada");
  console.log(`Insertados: ${inserted}`);
  console.log(`Actualizados: ${updated}`);
  console.log(`Omitidos: ${skipped}`);
  console.log("===================================");
}

async function run() {
  try {
    console.log("Verificando tabla municipalities...");
    await ensureMunicipalitiesTable();

    console.log("Importando municipios...");
    await importMunicipalities();

    console.log("Proceso completado correctamente.");
  } catch (error) {
    console.error("Error en importMunicipalities:", error.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

run();