const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

async function run() {
  try {
    console.log("Convirtiendo TODOS los festivales a REAL...");

    const result = await pool.query(`
      UPDATE festivals
      SET 
        source_type = 'real',
        verified = true,
        is_active = true;
    `);

    console.log("Festivales convertidos:", result.rowCount);

    await pool.end();
  } catch (err) {
    console.error("Error:", err.message);
    await pool.end();
    process.exit(1);
  }
}

run();